﻿'Program: StreamReadAndWrite
'me. frmSplash.vb
'Date: 4-May-2020
'Purpose: A simple splash screen
Public Class frmSplash
    Private Sub tmrData_Tick(sender As Object, e As EventArgs) Handles tmrData.Tick
        Me.Close()
    End Sub
End Class