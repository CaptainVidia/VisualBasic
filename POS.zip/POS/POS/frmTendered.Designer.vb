﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTendered
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblTenderedVal = New System.Windows.Forms.Label()
        Me.lblNetVal = New System.Windows.Forms.Label()
        Me.lblStateVal = New System.Windows.Forms.Label()
        Me.lblLocalVal = New System.Windows.Forms.Label()
        Me.lblTotalVal = New System.Windows.Forms.Label()
        Me.lblTendered = New System.Windows.Forms.Label()
        Me.lblMercHire = New System.Windows.Forms.Label()
        Me.lblCommissionTax = New System.Windows.Forms.Label()
        Me.lblAgencyTax = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btnDecPt = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.ttpTendered = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblTenderedVal
        '
        Me.lblTenderedVal.BackColor = System.Drawing.Color.Black
        Me.lblTenderedVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTenderedVal.Font = New System.Drawing.Font("Arial", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTenderedVal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTenderedVal.Location = New System.Drawing.Point(29, 56)
        Me.lblTenderedVal.Name = "lblTenderedVal"
        Me.lblTenderedVal.Size = New System.Drawing.Size(231, 54)
        Me.lblTenderedVal.TabIndex = 1
        Me.lblTenderedVal.Tag = "14"
        Me.lblTenderedVal.Text = "0.00"
        Me.lblTenderedVal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblNetVal
        '
        Me.lblNetVal.BackColor = System.Drawing.Color.Black
        Me.lblNetVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblNetVal.Font = New System.Drawing.Font("Arial", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNetVal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblNetVal.Location = New System.Drawing.Point(472, 27)
        Me.lblNetVal.Name = "lblNetVal"
        Me.lblNetVal.Size = New System.Drawing.Size(214, 54)
        Me.lblNetVal.TabIndex = 2
        Me.lblNetVal.Tag = "15"
        Me.lblNetVal.Text = "0.00"
        Me.lblNetVal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblStateVal
        '
        Me.lblStateVal.BackColor = System.Drawing.Color.Black
        Me.lblStateVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStateVal.Font = New System.Drawing.Font("Arial", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStateVal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblStateVal.Location = New System.Drawing.Point(472, 95)
        Me.lblStateVal.Name = "lblStateVal"
        Me.lblStateVal.Size = New System.Drawing.Size(214, 54)
        Me.lblStateVal.TabIndex = 3
        Me.lblStateVal.Tag = "16"
        Me.lblStateVal.Text = "0.00"
        Me.lblStateVal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblLocalVal
        '
        Me.lblLocalVal.BackColor = System.Drawing.Color.Black
        Me.lblLocalVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLocalVal.Font = New System.Drawing.Font("Arial", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocalVal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblLocalVal.Location = New System.Drawing.Point(472, 165)
        Me.lblLocalVal.Name = "lblLocalVal"
        Me.lblLocalVal.Size = New System.Drawing.Size(214, 54)
        Me.lblLocalVal.TabIndex = 4
        Me.lblLocalVal.Tag = "17"
        Me.lblLocalVal.Text = "0.00"
        Me.lblLocalVal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTotalVal
        '
        Me.lblTotalVal.BackColor = System.Drawing.Color.Black
        Me.lblTotalVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalVal.Font = New System.Drawing.Font("Arial", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalVal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTotalVal.Location = New System.Drawing.Point(472, 231)
        Me.lblTotalVal.Name = "lblTotalVal"
        Me.lblTotalVal.Size = New System.Drawing.Size(214, 54)
        Me.lblTotalVal.TabIndex = 5
        Me.lblTotalVal.Tag = "18"
        Me.lblTotalVal.Text = "0.00"
        Me.lblTotalVal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTendered
        '
        Me.lblTendered.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTendered.Location = New System.Drawing.Point(26, 28)
        Me.lblTendered.Name = "lblTendered"
        Me.lblTendered.Size = New System.Drawing.Size(178, 29)
        Me.lblTendered.TabIndex = 6
        Me.lblTendered.Tag = "19"
        Me.lblTendered.Text = "Tendered:"
        '
        'lblMercHire
        '
        Me.lblMercHire.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMercHire.Location = New System.Drawing.Point(332, 49)
        Me.lblMercHire.Name = "lblMercHire"
        Me.lblMercHire.Size = New System.Drawing.Size(120, 29)
        Me.lblMercHire.TabIndex = 7
        Me.lblMercHire.Tag = "20"
        Me.lblMercHire.Text = "Statue Order:"
        Me.lblMercHire.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCommissionTax
        '
        Me.lblCommissionTax.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCommissionTax.Location = New System.Drawing.Point(308, 185)
        Me.lblCommissionTax.Name = "lblCommissionTax"
        Me.lblCommissionTax.Size = New System.Drawing.Size(144, 29)
        Me.lblCommissionTax.TabIndex = 8
        Me.lblCommissionTax.Tag = "22"
        Me.lblCommissionTax.Text = "Sculptor Tax:"
        Me.lblCommissionTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblAgencyTax
        '
        Me.lblAgencyTax.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAgencyTax.Location = New System.Drawing.Point(340, 115)
        Me.lblAgencyTax.Name = "lblAgencyTax"
        Me.lblAgencyTax.Size = New System.Drawing.Size(112, 29)
        Me.lblAgencyTax.TabIndex = 9
        Me.lblAgencyTax.Tag = "21"
        Me.lblAgencyTax.Text = "Tax:"
        Me.lblAgencyTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTotal
        '
        Me.lblTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(356, 253)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(96, 29)
        Me.lblTotal.TabIndex = 10
        Me.lblTotal.Tag = "23"
        Me.lblTotal.Text = "Total:"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.Color.Lime
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.Location = New System.Drawing.Point(601, 326)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(103, 58)
        Me.btnNext.TabIndex = 11
        Me.btnNext.Text = "&Next"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Lime
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(383, 326)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(103, 58)
        Me.btnClear.TabIndex = 12
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Lime
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(492, 326)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(103, 58)
        Me.btnBack.TabIndex = 13
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.Yellow
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(29, 256)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(73, 58)
        Me.btn1.TabIndex = 14
        Me.btn1.Tag = "1"
        Me.btn1.Text = "&1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.Yellow
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Location = New System.Drawing.Point(108, 256)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(73, 58)
        Me.btn2.TabIndex = 15
        Me.btn2.Tag = "2"
        Me.btn2.Text = "&2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.Yellow
        Me.btn7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.Location = New System.Drawing.Point(29, 128)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(73, 58)
        Me.btn7.TabIndex = 16
        Me.btn7.Tag = "7"
        Me.btn7.Text = "&7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.Yellow
        Me.btn8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.Location = New System.Drawing.Point(108, 128)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(73, 58)
        Me.btn8.TabIndex = 17
        Me.btn8.Tag = "8"
        Me.btn8.Text = "&8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.Yellow
        Me.btn9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.Location = New System.Drawing.Point(187, 128)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(73, 58)
        Me.btn9.TabIndex = 18
        Me.btn9.Tag = "9"
        Me.btn9.Text = "&9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.Yellow
        Me.btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.Location = New System.Drawing.Point(30, 192)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(73, 58)
        Me.btn4.TabIndex = 19
        Me.btn4.Tag = "4"
        Me.btn4.Text = "&4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.Yellow
        Me.btn5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.Location = New System.Drawing.Point(108, 192)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(73, 58)
        Me.btn5.TabIndex = 20
        Me.btn5.Tag = "5"
        Me.btn5.Text = "&5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.Yellow
        Me.btn6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.Location = New System.Drawing.Point(187, 192)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(73, 58)
        Me.btn6.TabIndex = 21
        Me.btn6.Tag = "6"
        Me.btn6.Text = "&6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.Yellow
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Location = New System.Drawing.Point(187, 256)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(73, 58)
        Me.btn3.TabIndex = 22
        Me.btn3.Tag = "3"
        Me.btn3.Text = "&3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btnDecPt
        '
        Me.btnDecPt.BackColor = System.Drawing.Color.Yellow
        Me.btnDecPt.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDecPt.Location = New System.Drawing.Point(187, 320)
        Me.btnDecPt.Name = "btnDecPt"
        Me.btnDecPt.Size = New System.Drawing.Size(73, 58)
        Me.btnDecPt.TabIndex = 23
        Me.btnDecPt.Tag = "10"
        Me.btnDecPt.Text = "&."
        Me.btnDecPt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnDecPt.UseVisualStyleBackColor = False
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.Color.Yellow
        Me.btn0.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.Location = New System.Drawing.Point(30, 320)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(151, 58)
        Me.btn0.TabIndex = 24
        Me.btn0.Tag = "0"
        Me.btn0.Text = "&0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'frmTendered
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(800, 498)
        Me.ControlBox = False
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btnDecPt)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblAgencyTax)
        Me.Controls.Add(Me.lblCommissionTax)
        Me.Controls.Add(Me.lblMercHire)
        Me.Controls.Add(Me.lblTendered)
        Me.Controls.Add(Me.lblTotalVal)
        Me.Controls.Add(Me.lblLocalVal)
        Me.Controls.Add(Me.lblStateVal)
        Me.Controls.Add(Me.lblNetVal)
        Me.Controls.Add(Me.lblTenderedVal)
        Me.Name = "frmTendered"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AOT Jaeger Statue Tendered"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblTenderedVal As Label
    Friend WithEvents lblNetVal As Label
    Friend WithEvents lblStateVal As Label
    Friend WithEvents lblLocalVal As Label
    Friend WithEvents lblTotalVal As Label
    Friend WithEvents lblTendered As Label
    Friend WithEvents lblMercHire As Label
    Friend WithEvents lblCommissionTax As Label
    Friend WithEvents lblAgencyTax As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnNext As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btnDecPt As Button
    Friend WithEvents btn0 As Button
    Friend WithEvents ttpTendered As ToolTip
End Class
