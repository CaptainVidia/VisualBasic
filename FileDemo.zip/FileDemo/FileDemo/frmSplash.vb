﻿'Program: File Demo
'me. frmSplash.vb
'Date: 15-May-2020
'Purpose: splash form for program
Public Class frmSplash
    Private Sub tmerData_Tick(sender As Object, e As EventArgs) Handles tmerData.Tick
        Me.Close()

    End Sub
End Class