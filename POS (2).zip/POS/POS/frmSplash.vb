﻿'Program: AOT Sculpture Sale
' Me:frmSplash.vb
' Date: 4/20/2020
'Author: G.Tang
'Purpose: a simple splash form for the program
Public Class frmSplash
    Private Sub timerData_Tick(sender As Object, e As EventArgs) Handles timerData.Tick
        Me.Close()
    End Sub


End Class